const nums = [4, 1, 2, 8, 2, 8, 6];

// console.log(nums.indexOf(80));
// console.log(nums.includes(80));

// nums.sort();

const subArray = nums.slice(2, 4);

console.log(subArray);

// const words = [
//     "Apple",
//     "Banana",
//     "Cherry",
//     12,
//     true,
//     {
//         name: "Anuj",
//     },
//     function hello() {
//         console.log("hello world");
//     },
// ];

// const newWords = words;

// newWords[6] = "Kiwi";

// console.log(words);
// console.log(newWords);
