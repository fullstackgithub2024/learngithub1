const greet = (count) => {
    for (let i = 0; i < count; i++) console.log("Hello World");
};

greet(3);

const square = (num) => {
    return num * num;
};

console.log(square(3));
